﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entity
{
    /// <summary>
    /// Employee ID :
    /// Employee Name : 
    /// Description : This is entity class for the student information
    /// Date of Creattion :
    /// </summary>
    public class Student
    {
        //Get or set Student code
        public int StudCode { get; set; }
        //Get or set Student Name
        public string StudName { get; set; }
        //Get or set Department Code
        public int DeptCode { get; set; }
        //Get or Set Student Date of Birth
        public DateTime DOB { get; set; }
        //Get or set Student Address
        public string Address { get; set; }
    }
}
