﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDAL;
using EmployeeEntity;
using EmployeeException;


namespace EmployeeBL
{
    public class EmployeeBL
    {
        EmployeeDAL.EmployeeDAL EmpDAL = new EmployeeDAL.EmployeeDAL();       

        public Employee SearchEmployeeBL(int searchEmployeeID)
        {
           
            Employee searchEmployee = null;
            try
            {
                searchEmployee = EmpDAL.SearchEmployeeDAL(searchEmployeeID);
            }
            catch (EmployeeException.EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchEmployee;

        }
        public bool UpdateEmployeeBL(Employee updateEmployee)
        {
            bool EmployeeUpdated = false;
            try
            {              
                EmployeeUpdated = EmpDAL.UpdateEmployeeDAL(updateEmployee);
            }
            catch (EmployeeException.EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return EmployeeUpdated;
        }

    }
}
