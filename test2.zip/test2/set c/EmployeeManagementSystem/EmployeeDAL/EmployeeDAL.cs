﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EmployeeEntity;
using EmployeeException;

namespace EmployeeDAL
{
  
    public class EmployeeDAL
    {
        SqlConnection connection = new SqlConnection(GlobalData.ConnectionString);
        public Employee SearchEmployeeDAL(int searchEmployeeID)
        {
            Employee searchEmployee = null;
            try
            {
                string Query = "SearchEmployee_166026_C";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Employeeid", searchEmployeeID);
                connection.Open();
                SqlDataReader Reader = command.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {
                        searchEmployee = new Employee();
                        searchEmployee.EmployeeId = int.Parse(Reader[0].ToString());
                        searchEmployee.Department = Reader[1].ToString();
                        searchEmployee.MaritalStatus = Reader[2].ToString();
                        searchEmployee.PersonalPhoneNumber = Reader[3].ToString(); 
                        searchEmployee.EmergncyContactNumber = long.Parse(Reader[4].ToString());
                        searchEmployee.PassportDetails = Reader[5].ToString();
                        searchEmployee.HomeMailingAddress = Reader[6].ToString();
                        searchEmployee.PANNumber = Reader[7].ToString();
                        searchEmployee.AdharNumber = long.Parse(Reader[8].ToString());
                        searchEmployee.City =  Reader[9].ToString();
                    }
                }
                connection.Close();

            }
            catch (Exception ex)
            {
                throw new EmployeeException.EmployeeException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return searchEmployee;
        }

        public bool UpdateEmployeeDAL(Employee updateEmployee)
        {
            bool EmployeeUpdated = false;
            try
            {
                string Query = "UpdateEmployee_166026_C";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Employeeid", updateEmployee.EmployeeId);
                command.Parameters.AddWithValue("@EmployeePhone", updateEmployee.PersonalPhoneNumber);
                command.Parameters.AddWithValue("@EmployeeContact", updateEmployee.EmergncyContactNumber);
                command.Parameters.AddWithValue("@EmployeeCity", updateEmployee.City);
               
                connection.Open();
                command.ExecuteNonQuery();

                EmployeeUpdated = true;
                connection.Close();

            }
            catch (Exception ex)
            {
                throw new EmployeeException.EmployeeException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }

            return EmployeeUpdated;

        }
    }
}
