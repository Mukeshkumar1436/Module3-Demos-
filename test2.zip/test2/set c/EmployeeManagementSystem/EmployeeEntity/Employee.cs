﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeEntity
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string Department { get; set; }
        public string MaritalStatus { get; set; }
        public string PersonalPhoneNumber { get; set; }
        public long  EmergncyContactNumber { get; set; }
        public string PassportDetails { get; set; }
        public string HomeMailingAddress { get; set; }
        public string PANNumber { get; set; }
        public long AdharNumber { get; set; }
        public string City { get; set; }
    }
}
