﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmployeeEntity;
using EmployeeException;
using EmployeeBL;

namespace EmployeePL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        EmployeeBL.EmployeeBL EmpBL = new EmployeeBL.EmployeeBL();
        StringBuilder sb = new StringBuilder();
        public MainWindow()
        {
            InitializeComponent();
        }
        private bool ValidateEmployee(Employee Employee)
        {
          
            bool validEmployee = true;

            if (Employee.EmployeeId.ToString().Length != 6)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Id should be of 6 digit");
            }
            if (Employee.PersonalPhoneNumber.ToString().Length != 12)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Personal Phone number should be of 10 digit");
            }
            if (Employee.EmergncyContactNumber.ToString().Length != 10)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Personal Phone number should be of 10 digit");
            }

            if (Employee.City.Equals("Mumbai") || Employee.City.Equals("Pune") || Employee.City.Equals("Chennai") ||
                    Employee.City.Equals("Banglore") || Employee.City.Equals("Hyderabad") || Employee.City.Equals("Noida"))
            { }
            else { 
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee city should be Mumbai/Pune/Banglore/Hyderabad/Chennai/Noida ");
            }

                      
            return validEmployee;
        }
        private Employee SearchEmployeeByID()
        {
            Employee searchEmployee = null;
            try
           {                
                int searchEmployeeID = int.Parse(txtEmpid.Text);                
                    searchEmployee = EmpBL.SearchEmployeeBL(searchEmployeeID);
                           
            }
            catch (EmployeeException.EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return searchEmployee;
        }
        private bool UpdateEmployee()
        {
            bool EmployeeUpdated = false;
            try
            {
                Employee Employee = new Employee();
                Employee.EmployeeId = int.Parse(txtEmpid.Text);
                Employee.PersonalPhoneNumber = txtPhone.Text;
                Employee.EmergncyContactNumber = long.Parse(txtContact.Text);
                Employee.City = txtCity.Text;             
                if (ValidateEmployee(Employee))
                {
                    EmployeeUpdated = EmpBL.UpdateEmployeeBL(Employee);
                }
                else
                {
                    MessageBox.Show(""+sb.ToString());                    
                }


            }
            catch (EmployeeException.EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return EmployeeUpdated;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {           
            Employee emp = SearchEmployeeByID();
            if (emp != null)
            {
                MessageBox.Show("Record Found");
                empGrp.Visibility = Visibility.Visible;
                txtDept.Text = emp.Department;
                txtMS.Text = emp.MaritalStatus;
                txtPhone.Text = emp.PersonalPhoneNumber;
                txtContact.Text = emp.EmergncyContactNumber.ToString();
                txtPassport.Text = emp.PassportDetails;
                txtAddress.Text = emp.HomeMailingAddress;
                txtPAN.Text = emp.PANNumber;
                txtAadhar.Text = emp.AdharNumber.ToString();
                txtCity.Text = emp.City;
            }
            else
                MessageBox.Show("Invalid Employee Id");
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            empGrp.Visibility = Visibility.Hidden;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (UpdateEmployee())
                MessageBox.Show("Data Saved");
            else
                MessageBox.Show("Data not Saved");
        }
    }
}
