--table
USE [Training_14Nov18_Mumbai]
GO

/****** Object:  Table [dbo].[Employee_166026_C]    Script Date: 07-01-2019 10:15:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Employee_166026_C](
	[EmployeeId] [int] NOT NULL,
	[Department] [varchar](50) NULL,
	[MaritalStatus] [varchar](50) NULL,
	[PersonalPhoneNumber] [varchar](50) NULL,
	[EmergncyContactNumber] [numeric](18, 0) NULL,
	[PassportDetails] [varchar](50) NULL,
	[HomeMailingAddress] [varchar](50) NULL,
	[PANNumber] [varchar](50) NULL,
	[AdharNumber] [numeric](18, 0) NULL,
	[City] [varchar](50) NULL,
 CONSTRAINT [PK_Employee_166026_C] PRIMARY KEY CLUSTERED 
(
	[EmployeeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

--Search

USE [Training_14Nov18_Mumbai]
GO

/****** Object:  StoredProcedure [dbo].[SearchStudent_166026]    Script Date: 05-01-2019 10:33:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SearchEmployee_166026_C]
	@Employeeid int	
AS
BEGIN

	SET NOCOUNT ON;

    SELECT * from Employee_166026_C where EmployeeId =@Employeeid
END

GO

--Update

USE [Training_14Nov18_Mumbai]
GO

/****** Object:  StoredProcedure [dbo].[SearchStudent_166026]    Script Date: 05-01-2019 10:33:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[UpdateEmployee_166026_C]
	@Employeeid int	,
	@EmployeePhone varchar(50)	,
	@EmployeeContact numeric	,
	@EmployeeCity varchar(50)	
AS
BEGIN

	SET NOCOUNT ON;

    UPDATE Employee_166026_C SET [PersonalPhoneNumber]= @EmployeePhone, [EmergncyContactNumber]= @EmployeeContact,
	[City]=@EmployeeCity where EmployeeId =@Employeeid
END

GO






