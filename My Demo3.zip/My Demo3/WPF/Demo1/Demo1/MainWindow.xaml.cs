﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Demo1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnSUBMIT_Click(object sender, RoutedEventArgs e)
        {
            int rollNo = int.Parse(txtRollNO.Text);
            if(rollNo >= 100000 && rollNo<=999999)
            {
                MessageBox.Show(rollNo.ToString());
                 
            }
            else
            {
                MessageBox.Show("roll no should be in the range of 100000 to 999999");
            }

            string name = txtName.Text;

            String gender = string.Empty;

            if (rbMale.IsChecked == true)
            {
                gender = rbMale.Content.ToString();
            }
            else if (rbFemale.IsChecked == true)
            {
                gender = rbFemale.Content.ToString();
            }

            string address = string.Empty;
            txtAddress.SelectAll();
            address = txtAddress.Selection.Text;

            DateTime dt = (DateTime)txtDOB.SelectedDate;
            string dob = dt.ToString("dd-MMM-yyyy");



            MessageBox.Show("roll no: " +rollNo+ "\n name: " +name+ "\n gender: " +gender+ "\n address: " +address+ "\n dob: " +dob);
        }
    }
}
