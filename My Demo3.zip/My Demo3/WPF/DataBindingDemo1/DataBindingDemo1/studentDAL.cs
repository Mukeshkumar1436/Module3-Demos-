﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBindingDemo1
{
    class studentDAL
    {
        List<student> students = null;


        public studentDAL()
        {
            students = new List<student>
            {
                new student{ RollNo=101, Name="mukesh",feespaid=4000},
                new student{ RollNo=102, Name="manoj",feespaid=2000},
                new student{ RollNo=103, Name="sai",feespaid=3000}
            };
        
        }
        public List<student> SelectAll()
        {
            return students;
        }
        internal void Insert(student s1)
        {
            students.Add(s1);
        }
    }
}
