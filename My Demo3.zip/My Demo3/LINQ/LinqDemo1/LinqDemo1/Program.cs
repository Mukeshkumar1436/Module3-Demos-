﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqDemo1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 12, 61, 66, 75, 78, 88, 97, 98 };
            int[] morenumbers = { 25, 30, 44, 65, 50, 67, 82, 77, 97 };

            //even
            var even = from num in numbers
                       where num % 2 == 0
                       select num;

            Console.WriteLine("even numbers are: ");
            foreach(var item in even)
            {
                Console.Write(item + "\t");
            }

            //sorting
            var sort = from num in numbers
                       orderby num
                       select num;
            Console.WriteLine("\n\nSorted Numbers are: ");
            foreach (var item in sort)
            {
                Console.Write(item + "\t");
            }

            //descending
            var desc = from num in numbers
                       orderby num descending
                       select num;
            Console.WriteLine("\n\nDescending Numbers are: ");
            foreach (var item in desc)
            {
                Console.Write(item + "\t");
            }

            //reverse
            var rev = numbers.Reverse();
                      
            Console.WriteLine("\n\nReverse Numbers are: ");
            foreach (var item in rev)
            {
                Console.Write(item + "\t");
            }

            //group
            var group = numbers.ToLookup(n => n % 2);

            Console.WriteLine("\n\nGrouped Numbers are: ");
            foreach (IGrouping<int,int> item in group)
            {
                Console.WriteLine("\nKey: " + item.Key);
                foreach(var val in item)
                {
                    Console.Write(val + "\t");
                }
            }

            var querry = numbers.Concat(morenumbers);
            Console.WriteLine("\n\nConcatinated Numbers are: ");
            foreach(var item in querry)
            {
                Console.Write(item + "\t");
            }

            Console.ReadKey();

        }
    }
}
