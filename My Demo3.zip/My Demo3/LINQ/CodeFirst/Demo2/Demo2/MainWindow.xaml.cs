﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Demo2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            InstrumentContext1 context = new InstrumentContext1();
            context.Instruments.Add(new Instrument() { ID = 101, Name="LAYS", Price=5, Quantity=10});
            //context.Instruments.Add(new Instrument() { ID = 102, Name = "BISCUIT", Price = 10, Quantity = 20 });
            //context.Instruments.Add(new Instrument() { ID = 103, Name = "CHOCOLATE", Price = 15, Quantity = 15 });

            context.SaveChanges();
            dgInstrument.ItemsSource = context.Instruments.ToList();

           

            var querry = from ins in context.Instruments
                         where ins.Price > 50
                         select ins;

            context.Instruments.Where(ins => ins.Price > 500);
        }
    }
}
