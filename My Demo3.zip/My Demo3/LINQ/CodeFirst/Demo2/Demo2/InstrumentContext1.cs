﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace Demo2
{
    class InstrumentContext1 : DbContext
    {
        public DbSet<Instrument> Instruments{get; set;}
    }
}
