﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CodeFirst
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
           
        }

        public void Clear()
        {
            txtcode.Text = "";
            txtName.Text = "";
            txtdeptcode.Text = "";
            txtDoB.Text = "";
            txtAddress.Text = "";
            btnSUBMIT2.IsEnabled = false;
            btnSUBMIT2.IsEnabled = false;
            txtcode.IsReadOnly = false;
            txtName.IsReadOnly = false;
            txtDoB.IsEnabled = true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowData();
        }

        public void ShowData()
        {
            TrainingEntities context = new TrainingEntities();
            dgStudent.ItemsSource = context.Student_master.ToList();
        }

       
        //insert
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Student_master stud = new Student_master();
            stud.Stud_Code = Convert.ToDecimal(txtcode.Text);
            stud.Stud_Name = txtName.Text;
            stud.Dept_Code = Convert.ToDecimal(txtdeptcode.Text);
            stud.Stud_Dob = Convert.ToDateTime(txtDoB.Text);
            stud.Address = txtAddress.Text;

            TrainingEntities context = new TrainingEntities();
            context.Student_master.Add(stud);
            int recordsAffected = context.SaveChanges();

            if (recordsAffected>0)
            {
                MessageBox.Show("Student record has been added");
                ShowData();
            }

            else
            {
                MessageBox.Show("Student record is not added");
            }
        }


        //search
        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            TrainingEntities context = new TrainingEntities();
            Student_master stud = context.Student_master.Find(Convert.ToInt32(txtcode.Text));

            if (stud != null)
            {
                gridStud.DataContext = stud;

                btnSUBMIT2.IsEnabled = true;
                btnSUBMIT3.IsEnabled = true;
            }
        }


        //update
        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            TrainingEntities context = new TrainingEntities();
            Student_master stud = context.Student_master.Find(Convert.ToInt32(txtcode.Text));

            stud.Stud_Name = txtName.Text;
            stud.Dept_Code = Convert.ToDecimal(txtdeptcode.Text);
            stud.Stud_Dob = Convert.ToDateTime(txtDoB.Text);
            stud.Address = txtAddress.Text;

           

            int recordsAffected = context.SaveChanges();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Student record has been Updated");
                ShowData();
            }

            else
            {
                MessageBox.Show("Student record is not Updated");
            }
        }


        //Delete
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            TrainingEntities context = new TrainingEntities();
            Student_master stud = context.Student_master.Find(Convert.ToInt32(txtcode.Text));

            context.Student_master.Remove(stud);
            int recordsAffected = context.SaveChanges();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Student record has been Deleted");
                ShowData();
            }

            else
            {
                MessageBox.Show("Student record is not Deleted");
            }

        }

        //Count
        private void BtnCount_Click(object sender, RoutedEventArgs e)
        {
            TrainingEntities context = new TrainingEntities();

            MessageBox.Show("number of employees are: " + context.Student_master.Count());
        }

        //Clear
        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

    }
}
