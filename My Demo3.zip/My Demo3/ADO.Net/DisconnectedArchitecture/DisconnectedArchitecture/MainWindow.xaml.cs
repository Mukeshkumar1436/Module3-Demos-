﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace DisconnectedArchitecture
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con; SqlCommand cmd; SqlDataReader dr; SqlDataAdapter da;
        DataSet ds = new DataSet();
        SqlCommandBuilder cmb = new SqlCommandBuilder();

        public MainWindow()
        {
            InitializeComponent();
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            da = new SqlDataAdapter("SELECT * FROM Student_Master",con);
            cmb = new SqlCommandBuilder(da);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            da.Fill(ds,"Stud");

            dgStudent.ItemsSource = ds.Tables["Stud"].DefaultView;
        }


        //Add OR Insert
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            DataRow dr = ds.Tables["Stud"].NewRow();
            dr["Stud_Code"] = txtcode.Text;
            dr["Stud_Name"] = txtName.Text;
            dr["Dept_Code"] = txtdeptcode.Text;
            dr["Stud_Dob"] = Convert.ToDateTime(txtDoB.Text);
            dr["Address"] = txtAddress.Text;

            ds.Tables["Stud"].Rows.Add(dr);

            int recordsAffected = da.Update(ds, "Stud");
            if(recordsAffected>0)
            {
                MessageBox.Show("student record upadated successfully");
                ClearData();
            }
            else
            {
                MessageBox.Show("student record not added");
            }

        }
        public void ClearData()
        {
            txtcode.Text = "";
            txtName.Text = "";
            txtdeptcode.Text = "";
            txtDoB.Text = "";
            txtAddress.Text = "";

            btnSUBMIT2.IsEnabled = false;
            btnSUBMIT3.IsEnabled = false;

        }

        //search
        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            DataRow dr = ds.Tables["Stud"].Rows.Find(txtcode.Text);
            
            if (dr!=null)
            {
                txtcode.Text = dr["Stud_Code"].ToString();
                txtName.Text = dr["Stud_Name"].ToString();
                txtdeptcode.Text = dr["Dept_Code"].ToString();
                txtDoB.Text = dr["Stud_Dob"].ToString();
                txtAddress.Text = dr["Address"].ToString();

                btnSUBMIT2.IsEnabled = true;
                btnSUBMIT3.IsEnabled = true;
            }
            else
            {
                MessageBox.Show("Student with id" + txtcode.Text + "not found");
            }
            con.Close();

        }


        //Update
        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
           
            for (int i = 0; i < ds.Tables["Stud"].Rows.Count; i++)
            {
                if (ds.Tables["Stud"].Rows[i]["Stud_Code"].ToString() == txtcode.Text)
                {
                    ds.Tables["Stud"].Rows[i]["Stud_Name"] = txtName.Text;
                    ds.Tables["Stud"].Rows[i]["Dept_Code"] = txtdeptcode.Text;
                    ds.Tables["Stud"].Rows[i]["Stud_Dob"] = Convert.ToDateTime(txtDoB.Text);
                    ds.Tables["Stud"].Rows[i]["Address"] = txtAddress.Text;

                }
            }

          
            int recordsAffected = da.Update(ds,"Stud");
            
            if (recordsAffected > 0)
            {
                MessageBox.Show("Student record updated successfully");

                ClearData();
            }
            else
            {
                MessageBox.Show("Student record not updated");
            }
            void ClearData()
            {
                txtcode.Text = "";
                txtName.Text = "";
                txtdeptcode.Text = "";
                txtDoB.Text = "";
                txtAddress.Text = "";

                btnSUBMIT2.IsEnabled = false;
                btnSUBMIT3.IsEnabled = false;
            }

        }


        //Delete
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            DataRow dr = ds.Tables["Stud"].Rows.Find(txtcode.Text);

            //ds.Tables["Stud"].Rows.Remove(dr);
            dr.Delete();
            int recordsAffected = da.Update(ds, "Stud");
            
            if (recordsAffected > 0)
            {
                MessageBox.Show("Student record Deleted successfully");
                ClearData();
            }
            else
            {
                MessageBox.Show("Student record not Deleted");
            }
            void ClearData()
            {
                txtcode.Text = "";
                txtName.Text = "";
                txtdeptcode.Text = "";
                txtDoB.Text = "";
                txtAddress.Text = "";

                btnSUBMIT2.IsEnabled = false;
                btnSUBMIT3.IsEnabled = false;
            }
        }


        //count
        private void BtnCount_Click(object sender, RoutedEventArgs e)
        {
            

            MessageBox.Show("Number of Students are :" + ds.Tables["Stud"].Rows.Count);

        }


        //clear or Reset
        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            ClearData();
            MessageBox.Show("cleared");
        }
    }
}
