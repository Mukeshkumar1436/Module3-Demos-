﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities_SI;       //Reference to Entity library
using Exceptions_SI;    //Reference to Exeption Library
using System.Data.SqlClient;


namespace DAL_SI
{
    public class StudentOperationDAL
    {
        //Function to insert student record in database
        public static int InsertStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnectionDAL.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertStudent";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Stud_Code", stud.Stud_Code);
                cmd.Parameters.AddWithValue("@Stud_Name", stud.Stud_Name);
                cmd.Parameters.AddWithValue("@Dept_Code", stud.Dept_Code);
                cmd.Parameters.AddWithValue("@DOB", stud.Stud_DoB);
                cmd.Parameters.AddWithValue("@Address", stud.Address);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to update student record from database
        public static int UpdateStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnectionDAL.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdateStudent";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Stud_Code", stud.Stud_Code);
                cmd.Parameters.AddWithValue("@Dept_Code", stud.Dept_Code);
                cmd.Parameters.AddWithValue("@Address", stud.Address);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to delete student record from database
        public static int DeleteStudent(int studCode)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnectionDAL.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteStudent";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Stud_Code", studCode);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to search student record based on Student Code
        public static Student SearchStudent(int studCode)
        {
            Student stud = null;

            try
            {
                SqlCommand cmd = DataConnectionDAL.GenerateCommand();

                cmd.CommandText = "usp_SearchStudent";
                cmd.Parameters.AddWithValue("@Stud_Code", studCode);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    stud = new Student();
                    dr.Read();
                    stud.Stud_Code = (int)dr["Stud_Code"];
                    stud.Stud_Name = dr["Stud_Name"].ToString();
                    stud.Dept_Code = (int)dr["Dept_Code"];
                    stud.Stud_DoB = Convert.ToDateTime(dr["Stud_DoB"]);
                    stud.Address = dr["Address"].ToString();
                }
                else
                {
                    throw new StudentException("Record not found");
                }
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        //Function to retrieve all student record
        public static List<Student> RetrieveStudent()
        {
            List<Student> studList = null;

            try
            {
                SqlCommand cmd = DataConnectionDAL.GenerateCommand();
                cmd.CommandText = "usp_DisplayStudent";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    studList = new List<Student>();
                    while (dr.Read())
                    {
                        Student stud = new Student();

                        stud.Stud_Code = (int)dr["Stud_Code"];
                        stud.Stud_Name = dr["Stud_Name"].ToString();
                        stud.Dept_Code = (int)dr["Dept_Code"];
                        stud.Stud_DoB = Convert.ToDateTime(dr["Stud_DoB"]);
                        stud.Address = dr["Address"].ToString();
                        studList.Add(stud);
                    }
                }
                else
                    throw new StudentException("Record not available");
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
    }
}
