﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Entities_SI;
using Exceptions_SI;
using BAL_SI;

namespace StudentInformation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public void Clear()
        {
            txtcode.Text = "";
            txtName.Text = "";
            txtdeptcode.Text = "";
            txtDoB.Text = "";
            txtAddress.Text = "";
            btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;
            txtcode.IsReadOnly = false;
            txtName.IsReadOnly = false;
            txtDoB.IsEnabled = true;
        }

        public void Show()
        {
            try
            {
                List<Student> studList = StudentValidationBAL.RetrieveStudent();

                if (studList == null || studList.Count <= 0)
                    throw new StudentException("Records not available");
                else
                {
                    dgStudent.DataContext = studList;
                }
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Student stud = new Student();

                stud.Stud_Code = Convert.ToInt32(txtcode.Text);
                stud.Stud_Name = txtName.Text;
                stud.Dept_Code = Convert.ToInt32(txtdeptcode .Text);
                stud.Stud_DoB = Convert.ToDateTime(txtDoB.Text);
                stud.Address = txtAddress.Text;

                int recordsAffected = StudentValidationBAL.InsertStudent(stud);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record inserted successfully");
                    Show();
                    Clear();
                }
                else
                    throw new StudentException("Record not inserted");
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int studCode = Convert.ToInt32(txtcode.Text);

                Student stud = StudentValidationBAL.SearchStudent(studCode);

                if (stud != null)
                {
                    txtcode.Text = stud.Stud_Code.ToString();
                    txtName.Text = stud.Stud_Name;
                    txtdeptcode.Text = stud.Dept_Code.ToString();
                    txtDoB.Text = stud.Stud_DoB.ToString();
                    txtAddress.Text = stud.Address;

                    btnUpdate.IsEnabled = true;
                    btnDelete.IsEnabled = true;
                    txtcode.IsReadOnly = true;
                    txtName.IsReadOnly = true;
                    txtDoB.IsEnabled = false;
                }
                else
                    throw new StudentException("Student record not found");
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Student stud = new Student();

                stud.Stud_Code = Convert.ToInt32(txtcode.Text);
                stud.Stud_Name = txtName.Text;
                stud.Dept_Code = Convert.ToInt32(txtdeptcode.Text);
                stud.Stud_DoB = Convert.ToDateTime(txtDoB.Text);
                stud.Address = txtAddress.Text;

                int recordsAffected = StudentValidationBAL.UpdateStudent(stud);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully");
                    Show();
                    Clear();
                }
                else
                    throw new StudentException("Record not updated");
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int studCode = Convert.ToInt32(txtcode.Text);

                int recordsAffected = StudentValidationBAL.DeleteStudent(studCode);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully");
                    Show();
                    Clear();
                }
                else
                    throw new StudentException("Record not deleted");
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCount_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
    }
}
