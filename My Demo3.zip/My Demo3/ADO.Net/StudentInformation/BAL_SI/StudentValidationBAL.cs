﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities_SI;
using Exceptions_SI;
using DAL_SI;
using System.Text.RegularExpressions;

namespace BAL_SI
{
    public class StudentValidationBAL
    {
        public static bool ValildateStudent(Student stud)
        {
            bool studValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (stud.Stud_Code <= 0)
                {
                    studValidated = false;
                    message.Append("Student code should be greater than 0\n");
                }

                if (stud.Stud_Name == String.Empty)
                {
                    studValidated = false;
                    message.Append("Student name should be provided\n");
                }
                else if (!Regex.IsMatch(stud.Stud_Name, "[A-Z][a-z]+"))
                {
                    studValidated = false;
                    message.Append("Student name should have alphabets only\n");
                }

                if (stud.Stud_DoB == null)
                {
                    studValidated = false;
                    message.Append("Student Date of Birth should be provided\n");
                }

                if (studValidated == false)
                    throw new StudentException(message.ToString());
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }

        public static int InsertStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateStudent(stud))
                {
                    recordsAffected = StudentOperationDAL.InsertStudent(stud);
                }
                else
                    throw new StudentException("Please provide valid Student Information");
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateStudent(stud))
                {
                    recordsAffected = StudentOperationDAL.UpdateStudent(stud);
                }
                else
                    throw new StudentException("Please provide valid Student Information");
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteStudent(int studCode)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = StudentOperationDAL.DeleteStudent(studCode);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Student SearchStudent(int studCode)
        {
            Student stud = null;

            try
            {
                stud = StudentOperationDAL.SearchStudent(studCode);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        public static List<Student> RetrieveStudent()
        {
            List<Student> studList = null;

            try
            {
                studList = StudentOperationDAL.RetrieveStudent();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
    }
}

