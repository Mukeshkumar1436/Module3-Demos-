﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DAL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
    private void BtnSearch_Click(object sender, RoutedEventArgs e)
    {
        cmd = new SqlCommand("SELECT * FROM Student_Master WHERE Stud_Code=@scode", con);
        cmd.Parameters.AddWithValue("@scode", txtcode.Text);
        con.Open();
        dr = cmd.ExecuteReader();

    }
}
