﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities_SI
{
    public class Student
    {
        //Get or set Student code
        public int Stud_Code;
        //Get or set Student Name
        public string Stud_Name;
        //Get or set Department Code
        public int Dept_Code;
        //Get or Set Student Date of Birth
        public DateTime Stud_DoB;
        //Get or set Student Address
        public string Address;
    }
}
