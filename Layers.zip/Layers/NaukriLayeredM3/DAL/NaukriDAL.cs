﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exception1;
using Entity;
using System.Data.SqlClient;

namespace DAL
{
    public class NaukriDAL
    {

        public static int InsertStudent(NaukriEntity naukriEntity)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_Add_naukri";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@FullName", naukriEntity.FullName);
                cmd.Parameters.AddWithValue("@EmailId", naukriEntity.EmailId);
                cmd.Parameters.AddWithValue("@MobileNumber", naukriEntity.MobileNumber);
                cmd.Parameters.AddWithValue("@DOB", naukriEntity.DOB);
                cmd.Parameters.AddWithValue("@Gender", naukriEntity.Gender);
                cmd.Parameters.AddWithValue("@Skills", naukriEntity.Skills);
                cmd.Parameters.AddWithValue("@State", naukriEntity.State);
                cmd.Parameters.AddWithValue("@City", naukriEntity.City);
                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        public static List<NaukriEntity> RetrieveNaukri()
        {
            List<NaukriEntity> NaukriList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_display_naukri";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    NaukriList = new List<NaukriEntity>();
                    while (dr.Read())
                    {
                        NaukriEntity naukriEntity = new NaukriEntity();

                        naukriEntity.FullName = dr["FullName"].ToString();
                        naukriEntity.EmailId = dr["EmailId"].ToString();
                        naukriEntity.MobileNumber = dr["MobileNumber"].ToString();
                        naukriEntity.DOB = Convert.ToDateTime(dr["DOB"].ToString());
                        naukriEntity.Gender = dr["Gender"].ToString();
                        naukriEntity.Skills = dr["Skills"].ToString();
                        naukriEntity.State = dr["State"].ToString();
                        naukriEntity.City = dr["City"].ToString();


                        NaukriList.Add(naukriEntity);
                    }
                }
                else
                {
                    throw new NaukriException("Record not available");
                }
                cmd.Connection.Close();
            }
            catch (NaukriException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return NaukriList;


        }
        public static NaukriEntity SearchStudent(string emailid)
        {
            NaukriEntity naukriEntity = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_search_naukri11";
                cmd.Parameters.AddWithValue("@EmailId", emailid);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    naukriEntity = new NaukriEntity();
                    dr.Read();
                    naukriEntity.FullName = dr["FullName"].ToString();
                    naukriEntity.EmailId = dr["EmailId"].ToString();
                    naukriEntity.MobileNumber = dr["MobileNumber"].ToString();
                    naukriEntity.DOB = Convert.ToDateTime(dr["DOB"].ToString());
                    naukriEntity.Gender = dr["Gender"].ToString();
                    naukriEntity.Skills = dr["Skills"].ToString();
                    naukriEntity.State = dr["State"].ToString();
                    naukriEntity.City = dr["City"].ToString();
                }
                else
                {
                    throw new NaukriException("Record not found in Table");
                }
                cmd.Connection.Close();
            }
            catch (NaukriException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return naukriEntity;
        }
        public static int UpdateStudent(NaukriEntity naukriEntity)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_update_naukri";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@FullName", naukriEntity.FullName);
                cmd.Parameters.AddWithValue("@EmailId", naukriEntity.EmailId);
                cmd.Parameters.AddWithValue("@MobileNumber",naukriEntity.MobileNumber);
              

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        public static int DeleteStudent(string emailid)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_delete_naukri";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@EmailId",emailid);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
