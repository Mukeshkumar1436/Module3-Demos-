﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exception1;
using Entity;
using DAL;
using System.Text.RegularExpressions;

namespace BAL
{
    public class NaukriBAL
    {

        public static bool ValildateStudent(NaukriEntity naukriEntity)
        {
            bool studValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (!Regex.IsMatch(naukriEntity.FullName,"[A-Z]{1}[a-z]{2,}"))
                {
                    studValidated = false;
                    message.Append("please enter full Name in  currect format i.e first latter should be capital\n");
                }
               
                if (!Regex.IsMatch(naukriEntity.EmailId , "[a-zA-Z0-9]{1,20}@[a-zA-Z]{5}.[a-zA-Z]{3}"))
                {
                   
                    studValidated = false;
                    message.Append("student emaid id should be in the currect format i.e abc@gmail.com format\n");
                }
                if (!Regex.IsMatch(naukriEntity.MobileNumber, "[6789][0-9]{9}"))
                {
                    studValidated = false;
                    message.Append("mobile number should be 10 digits and it should start with 6/7/8/9\n");
                }

                if (naukriEntity.DOB>DateTime.Now.AddYears(-16))
                {
                    studValidated = false;
                    message.Append("student DOB should be 16 years subraction from present year ,students who are born in  before year 2003 should have to apply\n");
                }
              

                if (studValidated == false)
                    throw new NaukriException(message.ToString());
            }
            catch (NaukriException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }
        public static int InsertStudent(NaukriEntity naukriEntity)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateStudent(naukriEntity))
                {
                    recordsAffected = NaukriDAL.InsertStudent(naukriEntity);
                }
                else
                    throw new NaukriException("Please provide valid Student Information");
            }
            catch (NaukriException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        public static List<NaukriEntity> RetrieveStudent()
        {
            List<NaukriEntity> naukriEntities= null;

            try
            {
                naukriEntities = NaukriDAL.RetrieveNaukri();
            }
            catch (NaukriException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return naukriEntities;
        }
        public static NaukriEntity SearchStudent(string emailId)
        {
            NaukriEntity naukriEntity = null;

            try
            {
                naukriEntity = NaukriDAL.SearchStudent(emailId);
            }
            catch (NaukriException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return naukriEntity; 
        }
        public static int UpdateStudent(NaukriEntity naukriEntity)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateStudent(naukriEntity))
                {
                    recordsAffected = NaukriDAL.UpdateStudent(naukriEntity);
                }
                else
                    throw new NaukriException("Please provide valid Student Information");
            }
            catch (NaukriException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteStudent(string emailid)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = NaukriDAL.DeleteStudent(emailid);
            }
            catch (NaukriException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

    }
}
