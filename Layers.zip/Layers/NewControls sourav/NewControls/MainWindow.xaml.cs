﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Controls_Entity;
using Controls_BAL;
using Controls_Exception;

namespace NewControls
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        SqlCommand cmd;
        SqlDataReader dr;
        public MainWindow()
        {
            InitializeComponent();
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeDetails"].ConnectionString);
        }
        public void Clear()
        {
            txtEmpNo.Text = "";
            txtEmpname.Text = "";
            txtDeptNo.Text = "";
            txtDOB.Text = "";
            txtAddress.Text = "";
            btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;
            txtEmpNo.IsReadOnly = false;
            txtEmpname.IsReadOnly = false;
            txtDOB.IsEnabled = true;
        }

        public void Show()
        {
            try
            {
                List<EmployeeEntity> empList = EmployeeBAL.RetrieveEmployee();

                if (empList == null || empList.Count <= 0)
                    throw new ValidationException("Records not available");
                else
                {
                    digrid.DataContext = empList;
                }
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeEntity Emp = new EmployeeEntity();

                Emp.Employee_NO = Convert.ToInt32(txtEmpNo.Text);
                Emp.Employee_Name = txtEmpname.Text;
                Emp.Employee_DeptNo = Convert.ToInt32(txtDeptNo.Text);
                Emp.Employee_DOB = Convert.ToDateTime(txtDOB.Text);
                Emp.Employee_Address = txtAddress.Text;

                string gender = string.Empty;
                if ((bool)rbGenderM.IsChecked)
                    gender = rbGenderM.Content.ToString();
                else
                    if ((bool)rbGenderF.IsChecked)
                    gender = rbGenderF.Content.ToString();
                Emp.Employee_Gender = gender;

                //StringBuilder sbData = new StringBuilder();
                string listbx = string.Empty;
                ListBoxItem it = (ListBoxItem)lb1.SelectedItem;
                if(it != null)
                    listbx = it.Content.ToString();
                Emp.Employee_PF_Location = listbx;
                int recordsAffected = EmployeeBAL.InsertEmployee(Emp);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record inserted successfully");
                    Show();
                    Clear();
                }
                else
                    throw new ValidationException("Record not inserted");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int empCode = Convert.ToInt32(txtEmpNo.Text);

                EmployeeEntity emp = EmployeeBAL.SearchEmployee(empCode);

                if (emp != null)
                {
                    txtEmpNo.Text = emp.Employee_NO.ToString();
                    txtEmpname.Text = emp.Employee_Name;
                    txtDeptNo.Text = emp.Employee_DeptNo.ToString();
                    txtDOB.Text = emp.Employee_DOB.ToString();
                    txtAddress.Text = emp.Employee_Address;

                    btnUpdate.IsEnabled = true;
                    btnDelete.IsEnabled = true;
                    txtEmpNo.IsReadOnly = true;
                    txtEmpname.IsReadOnly = true;
                    txtDOB.IsEnabled = false;
                }
                else
                    throw new ValidationException("Student record not found");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeEntity emp = new EmployeeEntity();

                emp.Employee_NO = Convert.ToInt32(txtEmpNo.Text);
                emp.Employee_Name = txtEmpname.Text;
                emp.Employee_DeptNo = Convert.ToInt32(txtDeptNo.Text);
                emp.Employee_DOB = Convert.ToDateTime(txtDOB.Text);
                emp.Employee_Address = txtAddress.Text;

                string listbx = string.Empty;
                ListBoxItem it = (ListBoxItem)lb1.SelectedItem;
                if (it != null)

                    listbx = it.Content.ToString();
                emp.Employee_PF_Location = listbx;

                int recordsAffected = EmployeeBAL.UpdateEmployee(emp);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully");
                    Show();
                    Clear();
                }
                else
                    throw new ValidationException("Record not updated");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int empCode = Convert.ToInt32(txtEmpNo.Text);

                int recordsAffected = EmployeeBAL.DeleteEmployee(empCode);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully");
                    Show();
                    Clear();
                }
                else
                    throw new ValidationException("Record not deleted");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        private void BtnCount_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("SELECT COUNT(*) FROM Sourav_Master_", con);
            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();
            MessageBox.Show("Total number of Employees are :" + count);
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void RbGenderF_Checked(object sender, RoutedEventArgs e)
        {
            
        }

        private void RbGenderM_Checked(object sender, RoutedEventArgs e)
        {
           
        }
    }
    }