﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controls_Entity
{
    public class EmployeeEntity
    {
        public int Employee_NO { get; set; }
        public string Employee_Name { get; set; }
        public int Employee_DeptNo { get; set; }
        public DateTime Employee_DOB { get; set; }
        public string Employee_Address { get; set; }
        public string Employee_Gender { get; set; }
        public string Employee_PF_Location { get; set; }
    }
}
