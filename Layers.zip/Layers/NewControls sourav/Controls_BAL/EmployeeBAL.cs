﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Controls_Entity;
using Controls_DAL;
using Controls_Exception;
using System.Text.RegularExpressions;

namespace Controls_BAL
{
    public class EmployeeBAL
    {
        
        public static bool ValildateStudent(EmployeeEntity Emp)
        {
            bool empValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (Emp.Employee_NO <= 0)
                {
                    empValidated = false;
                    message.Append("Employee Number should be greater than 0\n");
                }

                if (Emp.Employee_Name == String.Empty)
                {
                    empValidated = false;
                    message.Append("Employee name should be provided\n");
                }
                else if (!Regex.IsMatch(Emp.Employee_Name, "[A-Z][a-z]+"))
                {
                    empValidated = false;
                    message.Append("Employee name should have alphabets only\n");
                }

                if (Emp.Employee_DOB == null)
                {
                    empValidated = false;
                    message.Append("Employee Date of Birth should be provided\n");
                }
                if(Emp.Employee_Address == String.Empty)
                {
                    empValidated = false;
                    message.Append("Employee Address should be provided");
                }
                if(Emp.Employee_Gender == String.Empty)
                {
                    empValidated = false;
                    message.Append("Employee Gender should be provided");
                }
                if(Emp.Employee_PF_Location == String.Empty)
                {
                    empValidated = false;
                    message.Append("Kindly select your Preferred location");
                }

                if (empValidated == false)
                    throw new ValidationException(message.ToString());
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empValidated;
        }

        public static int InsertEmployee(EmployeeEntity Emp)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateStudent(Emp))
                {
                    recordsAffected = EmployeeDAL.InsertEmployee(Emp);
                }
                else
                    throw new ValidationException("Please provide valid Employee Information");
            }
            catch (ValidationException ex)


            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateEmployee(EmployeeEntity Emp)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateStudent(Emp))
                {
                    recordsAffected = EmployeeDAL.UpdateEmployee(Emp);
                }
                else
                    throw new ValidationException("Please provide valid Employee Information");
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteEmployee(int EmpCode)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = EmployeeDAL.DeleteEmployee(EmpCode);
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static EmployeeEntity SearchEmployee(int EmpCode)
        {
            EmployeeEntity Emp = null;

            try
            {
                Emp = EmployeeDAL.SearchEmployee(EmpCode);
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return Emp;
        }

        public static List<EmployeeEntity> RetrieveEmployee()
        {
            List<EmployeeEntity> empList = null;

            try
            {
                empList = EmployeeDAL.RetrieveEmployee();
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empList;
        }
    }
}