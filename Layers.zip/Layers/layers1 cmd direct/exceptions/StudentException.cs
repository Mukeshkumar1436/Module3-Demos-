﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exceptions
{
    public class StudentException : ApplicationException
    {
        //default constructor
        public StudentException() : base()
        { }
        //paramaterised constructor
        public StudentException(string message) : base(message)
        { }
    }
    public class StudentNotValidDataException:ApplicationException
    {
        //student not valid data exception
        public StudentNotValidDataException(string message):base(message)
        { }
    }
}
