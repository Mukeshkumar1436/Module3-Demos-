﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entitiess
{
    public class Entities
    {
        public int escode;
        public string esname;
        public int edcode;
        public DateTime edob;
        public string eaddress;
        public override string ToString()
        {
            return $"Studentcode: {escode} \n EmpName: {esname} \n DeptCode: {edcode} \n Dob: {edob} \n Address: {eaddress}";
        }
    }
}
