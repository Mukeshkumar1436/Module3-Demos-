﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using bal;
using entitiess;
using exceptions;


namespace layers1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Bal bal = new Bal();  // business layer instance
        Entities entity = new Entities();  // entity class instance
       
        public MainWindow()
        {
            InitializeComponent();
           
        }
        private void Window_Loaded(object sender, RoutedEventArgs e) //window loaded event
        {
            try
            {
                showdata();  //show data in gridview
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);  //show graceful message if exception
            }
        }

        private void Button_Click_Add(object sender, RoutedEventArgs e)  //inserting the data
        {
            try
            {
                entity.escode = int.Parse(tscode.Text);
                entity.esname = tsname.Text;
                entity.edcode = int.Parse(tdcode.Text);
                entity.edob = Convert.ToDateTime(tdob.Text);
                entity.eaddress =taddress.Text;
                bal.Insert(entity);
                MessageBox.Show("added"); showdata();Clear();
            }
           catch(StudentNotValidDataException ex) 
            {
                MessageBox.Show(ex.Message);  
            }
            catch(StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Button_Click_Update(object sender, RoutedEventArgs e)
        {
            try
            {
                entity.escode = int.Parse(tscode.Text);
                entity.esname = tsname.Text;
                entity.edcode = int.Parse(tdcode.Text);
                entity.edob = Convert.ToDateTime(tdob.Text);
                entity.eaddress = taddress.Text;
                bal.Update(entity);
                MessageBox.Show("updated"); showdata();
            }
            catch (StudentNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void Button_Click_Search(object sender, RoutedEventArgs e)
        {
            try
            {
                entity.escode = int.Parse(tscode.Text);
                Entities dr = new Entities();
                dr = null;
                dr = bal.Search(entity.escode);

                MessageBox.Show("found the data");
                tscode.Text = Convert.ToString(dr.escode);
                tsname.Text = dr.esname;
                tdcode.Text = Convert.ToString(dr.edcode);
                tdob.Text = Convert.ToString(dr.edob);
                taddress.Text = dr.eaddress;
               
                update.IsEnabled = true; delete.IsEnabled = true;
            }
            catch (StudentNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void Button_Click_Delete(object sender, RoutedEventArgs e)
        {
            try
            {
                entity.escode = int.Parse(tscode.Text);
                bal.Delete(entity.escode);
                MessageBox.Show("Deleted the data");
                showdata();Clear();
            }
            catch (StudentNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click_Count(object sender, RoutedEventArgs e)
        {
            try
            {
               MessageBox.Show(  "Number of records:" + bal.Count());
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click_Clear(object sender, RoutedEventArgs e)
        {
            Clear();
        }
        public void showdata()
        {
            try
            {
                dgStudent.ItemsSource = bal.ShowData().DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void Clear()
        {
            tscode.Text =null ;
            tsname.Text =null;
            tdcode.Text = null;
            tdob.Text = null;
            taddress.Text = null;
            update.IsEnabled = false;
            delete.IsEnabled = false;
            
            
        }

        

        private void Button_Click_search_DeptCode(object sender, RoutedEventArgs e)
        {
            try
            {

                entity.edcode = int.Parse(tdcode.Text);
                IEnumerable<Entities> x = bal.SearchWithDeptCode(entity.edcode);
                foreach (Entities y in x)
                {
                    MessageBox.Show(y.ToString());
                }

            }

            catch (StudentNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
