﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using entitiess;
using exceptions;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace dal
{
    public class Dal
    {
        SqlCommand cmd; SqlConnection con; SqlDataReader dr;
        List<Entities> ent_db = new List<Entities>();

        public void Insert(Entities entity)
        {
            try
            {
                con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_23Jan19_Pune;uid=sqluser;pwd=sqluser");
                cmd = new SqlCommand("insert into student_master_172473(stud_code,stud_name,dept_code,stud_dob,address) values(@scode,@sname,@dcode,@sdob,@address)", con);
                cmd.Parameters.AddWithValue("@scode", entity.escode);
                cmd.Parameters.AddWithValue("@sname", entity.esname);
                cmd.Parameters.AddWithValue("@dcode", entity.edcode);
                cmd.Parameters.AddWithValue("@sdob", entity.edob);
                cmd.Parameters.AddWithValue("@address", entity.eaddress);
                con.Open();
                int s = cmd.ExecuteNonQuery();                
            }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            finally
            { con.Close(); }
        }


        public void Update(Entities entity)
        {
            try
            { 
            con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_23Jan19_Pune;uid=sqluser;pwd=sqluser");
            cmd = new SqlCommand("update student_master_172473 set stud_name=@sname,dept_code=@dcode,stud_dob=@sdob,Address=@address where stud_code=@scode", con);
            
            cmd.Parameters.AddWithValue("@sname", entity.esname);
            cmd.Parameters.AddWithValue("@dcode", entity.edcode);
            cmd.Parameters.AddWithValue("@sdob", entity.edob);
            cmd.Parameters.AddWithValue("@address", entity.eaddress);
            cmd.Parameters.AddWithValue("@scode", entity.escode);
            con.Open();
            int ra=cmd.ExecuteNonQuery();
                if (ra == 0) { throw new StudentException("0 rows effected"); }
            
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            { con.Close(); }
        }

        public void Delete(int id)
        {
            try
            { 
            con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_23Jan19_Pune;uid=sqluser;pwd=sqluser");
            cmd = new SqlCommand("delete  from student_master_172473  where stud_code=@scode", con);
            cmd.Parameters.AddWithValue("@scode", id);
            con.Open();
            int ra=cmd.ExecuteNonQuery();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            { con.Close(); }
        }

        public Entities Search_Display(int id)
        {
            try
            { 
            con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_23Jan19_Pune;uid=sqluser;pwd=sqluser");
            cmd = new SqlCommand("select * from student_master_172473  where stud_code=@scode", con);
            cmd.Parameters.AddWithValue("@scode",id);
            con.Open();
            dr = cmd.ExecuteReader();
            
            Entities ent = new Entities();
                
                    dr.Read();
                    ent.escode = Convert.ToInt32(dr["Stud_Code"]);
                    ent.edcode = Convert.ToInt32(dr["Dept_Code"]);
                    ent.esname = Convert.ToString(dr["Stud_Name"]);
                    ent.edob = (DateTime)dr["Stud_Dob"];
                    ent.eaddress = Convert.ToString(dr["Address"]);

             return ent;
                

            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            { con.Close(); }
        }

        public int count()
        {
            try
            {
                con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_23Jan19_Pune;uid=sqluser;pwd=sqluser");
                cmd = new SqlCommand("select count(*) from student_master_172473", con);
                con.Open();
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return count;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            finally
            { con.Close(); }

        }

        public IEnumerable<Entities> SearchWithDeptCode(int dcode)
        {
            try
            {
                con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_23Jan19_Pune;uid=sqluser;pwd=sqluser");

                cmd = new SqlCommand("select * from student_master_172473", con);

                con.Open();
                dr = cmd.ExecuteReader();
                Entities ent = new Entities();
                while (dr.Read())
                {
                    ent.escode = Convert.ToInt32(dr["Stud_Code"]);
                    ent.edcode = Convert.ToInt32(dr["Dept_Code"]);
                    ent.esname = Convert.ToString(dr["Stud_Name"]);
                    ent.edob = (DateTime)dr["Stud_Dob"];
                    ent.eaddress = Convert.ToString(dr["Address"]);
                    ent_db.Add(ent);
                }
               IEnumerable<Entities> q = from e in ent_db
                        where e.edcode == dcode
                        select e;
                return q;
            }
            
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }

        public DataTable ShowData()
        {
            try
            { 
            con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_23Jan19_Pune;uid=sqluser;pwd=sqluser");

            cmd = new SqlCommand("select * from student_master_172473", con);

            con.Open();
            dr = cmd.ExecuteReader();
            
            DataTable dt = new DataTable();
            dt.Load(dr);
            con.Close();
               
            //dgStudent.ItemsSource = dt.DefaultView;
             return dt;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }

        

    }
}
