﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using dal;
using entitiess;
using exceptions;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;



namespace bal
{
    
    public class Bal
    {
        
        Dal dal = new Dal();
        public void Insert(Entities entity)
        {
            try
            {
                bool validation = Is_valid(entity);
               
                 dal.Insert(entity);
                
            }
            catch(StudentNotValidDataException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }



        public void Update(Entities entity)
        {
            try
            {
                bool validation = Is_valid(entity);

                dal.Update(entity);

            }
            catch (StudentNotValidDataException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }


        public Entities Search(int id)
        {
            try
            {
                if (id <= 0)
                {
                    throw new StudentNotValidDataException("stud_code not valid");
                }
                return dal.Search_Display(id);
            }
            catch (StudentNotValidDataException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }


        public void Delete(int escode)
        {
            try
            {
                if (escode <= 0) { throw new StudentNotValidDataException("stud_code is not valid"); }
                dal.Delete(escode);
            }
            catch (StudentNotValidDataException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public int Count()
        {
            try
            {
                return dal.count();
            }
            catch(Exception ex)
            {
                throw ex;
            }

           
        }

       
        bool Is_valid(Entities entity)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( " ");
            bool valid = true;
            if (entity.escode <= 0)
            { valid = false; sb.Append(" student code must be unique and possitive\n"); }
            if (entity.esname == "")
            { valid = false; sb.Append("student name must be not null\n"); }
            if (entity.edcode <= 0)
            { valid = false; sb.Append("department code must be possitive\n"); }
            if (entity.edob >= DateTime.Today)
            { valid = false; sb.Append("date of birth  is must be past\n"); }
            if (entity.eaddress =="")
            { valid = false; sb.Append("address must not be null\n"); }
           
            if(!valid)
            {
                throw new StudentNotValidDataException(sb.ToString());
            }
            return valid;
        }
        //bool Is_exist(int id)
        //{

        //    SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_23Jan19_Pune;uid=sqluser;pwd=sqluser");

        //    SqlCommand cmd = new SqlCommand("select * from student_master where stud_code=@scode", con);
        //    cmd.Parameters.AddWithValue("@scode", id);
        //    con.Open();
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    if (dr.HasRows)
        //    {
        //        return true;
        //    }
        //    else { return false; }

        //}
        public DataTable ShowData()
        {
            try
            {
                return dal.ShowData();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public IEnumerable<Entities> SearchWithDeptCode(int edcode)
        {
            try
            {
                if (edcode <= 0) { throw new StudentNotValidDataException("dept_code is not valid"); }
                return dal.SearchWithDeptCode(edcode);
            }
            catch (StudentNotValidDataException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

        }
    }
}
