﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Student_Entities;
using Student_Exzception;
using System.Data.SqlClient;


namespace Student_DAL
{
    public class StudentOperation
    {
        public static int InsertStudent(StudentEntity stud)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_Insert";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Stud_code",stud.Scode);
                cmd.Parameters.AddWithValue("@Stud_Name", stud.SName);
                cmd.Parameters.AddWithValue("@Dept_Code", stud.DCode);
                cmd.Parameters.AddWithValue("@Dob", stud.Dob);
                cmd.Parameters.AddWithValue("@Address", stud.Address);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        public static StudentEntity SearchStudent(int studCode)
        {
            StudentEntity stud = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_Search";
                cmd.Parameters.AddWithValue("@Stud_Code", studCode);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    stud = new StudentEntity();
                    dr.Read();
                    stud.Scode = (int)dr["Stud_code"];
                    stud.SName = dr["Stud_Name"].ToString();
                    stud.DCode = (int)dr["Dept_Code"];
                    stud.Dob = Convert.ToDateTime(dr["Dob"]);
                    stud.Address = dr["Address"].ToString();
                }
                else
               {
                    throw new Student_Exce("Record not found");
                }
                cmd.Connection.Close();
            }
            catch (Student_Exce ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }
        public static int DeleteStudent(int studCode)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_Delete";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Stud_code", studCode);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        public static List<StudentEntity> RetrieveStudent()
        {
            List<StudentEntity> studList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_Display";
                
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    studList = new List<StudentEntity>();
                    while (dr.Read())
                    {
                        StudentEntity stud = new StudentEntity();

                        stud.Scode = (int)dr["Stud_code"];
                        stud.SName = dr["Stud_Name"].ToString();
                        stud.DCode = (int)dr["Dept_Code"];
                        stud.Dob = Convert.ToDateTime(dr["Dob"]);
                        stud.Address = dr["Address"].ToString();

                        studList.Add(stud);
                    }
                }
                else
                    throw new Student_Exce("Record not available");
                cmd.Connection.Close();
            }
            catch (Student_Exce ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
        public static int UpdateStudent(StudentEntity stud)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_Update_172424";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Stud_code", stud.Scode);
                cmd.Parameters.AddWithValue("@Stud_Name", stud.SName);
                cmd.Parameters.AddWithValue("@Dept_Code", stud.DCode);
                cmd.Parameters.AddWithValue("@Dob", stud.Dob);
                cmd.Parameters.AddWithValue("@Address", stud.Address);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

    }
}
