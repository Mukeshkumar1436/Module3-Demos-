CREATE TABLE StudentDetails_172467(
Stud_code int,
Stud_Name varchar(20) not null,
Dept_Code int,
Dob datetime,
Address varchar(50),
Gender varchar(10),  
State varchar(20)
);
SELECT * from StudentDetails_172467
go

-----insert
CREATE PROC usp_Insert_172467
(
@Stud_code int,
@Stud_Name varchar(20),
@Dept_Code int,
@Dob datetime,
@Address varchar(50)	,
@Gender varchar (50),
@State varchar(20)
)
AS
BEGIN
	INSERT INTO StudentDetails_172467
	VALUES(@Stud_code, @Stud_Name, @Dept_Code, @Dob, @Address,@Gender,@State)
END
go

----seasrch
CREATE PROC usp_Search_172467
(
	@Stud_code		INT
)
AS
BEGIN
	SELECT * FROM StudentDetails_172467
	WHERE Stud_code = @Stud_code
END

GO


-----------display
CREATE PROC usp_Display_172467
AS
BEGIN
	SELECT * FROM StudentDetails_172467
END
-------------delete
create proc usp_Delete_172467
(
@Stud_code int
)
as 
begin

delete from StudentDetails_172467 WHERE Stud_code = @Stud_code
end
-------count
create proc usp_Count_172467

as
begin

select count(*) from StudentDetails_172467 
end


 --update-----------------------------------------------------------------------------
 alter proc usp_Update_172467 
  (
    @Stud_code int,
@Stud_Name varchar(20),
@Dept_Code int,
@Dob datetime,
@Address varchar(50)	
--@Gender varchar(15),
--@State varchar(20)  
  )
 as 
 begin

 update StudentDetails_172467 SET Stud_Name = @Stud_Name, Dept_Code = @Dept_Code, Dob=@Dob, Address=@Address
 Where Stud_code = @Stud_code

 end

 drop proc usp_Update_172467