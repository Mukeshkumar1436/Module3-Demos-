--CREATE TABLE StudentDetails_172424(
--Stud_code int,
--Stud_Name varchar(20) not null,
--Dept_Code int,
--Dob datetime,
--Address varchar(50)  

--);
SELECT * from StudentDetails_172424
DELETE FROM StudentDetails_172424 where Stud_Name = 'Gowtham'
--CREATE PROC usp_Insert
--(
--@Stud_code int,
--@Stud_Name varchar(20),
--@Dept_Code int,
--@Dob datetime,
--@Address varchar(50)	
--)
--AS
--BEGIN
--	INSERT INTO StudentDetails_172424
--	VALUES(@Stud_code, @Stud_Name, @Dept_Code, @Dob, @Address)
--END

CREATE PROC usp_Search
(
	@Stud_code		INT
)
AS
BEGIN
	SELECT * FROM StudentDetails_172424
	WHERE Stud_code = @Stud_code
END

GO



CREATE PROC usp_Display
AS
BEGIN
	SELECT * FROM StudentDetails_172424
END


