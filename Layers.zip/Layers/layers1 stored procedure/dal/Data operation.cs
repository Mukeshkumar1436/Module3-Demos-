﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using entitiess;
using exceptions;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace dal
{
    public class Dal
    {
        SqlCommand cmd;  SqlDataReader dr;
        List<Entities> ent_db = new List<Entities>();

        public void Insert(Entities entity)
        {
            try
            {
                cmd = Data_connection.GenerateCommand();
                cmd.CommandText = "usp_insert_172473";
                cmd.Parameters.AddWithValue("@scode", entity.escode);
                cmd.Parameters.AddWithValue("@sname", entity.esname);
                cmd.Parameters.AddWithValue("@dcode", entity.edcode);
                cmd.Parameters.AddWithValue("@sdob", entity.edob);
                cmd.Parameters.AddWithValue("@address", entity.eaddress);
                cmd.Connection.Open();
                int s = cmd.ExecuteNonQuery();                
            }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            finally
            { cmd.Connection.Close(); }
        }


        public void Update(Entities entity)
        {
            try
            {
                cmd = Data_connection.GenerateCommand();
                cmd.CommandText = "usp_update_172473";
                cmd.Parameters.AddWithValue("@sname", entity.esname);
                cmd.Parameters.AddWithValue("@dcode", entity.edcode);
                cmd.Parameters.AddWithValue("@sdob", entity.edob);
                cmd.Parameters.AddWithValue("@address", entity.eaddress);
                cmd.Parameters.AddWithValue("@scode", entity.escode);
                cmd.Connection.Open();
                int ra=cmd.ExecuteNonQuery();
                if (ra == 0) { throw new StudentException("0 rows effected"); }
            
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            { cmd.Connection.Close(); }
        }

        public void Delete(int id)
        {
            try
            {
                cmd = Data_connection.GenerateCommand();
                cmd.CommandText = "usp_delete_172473";
                cmd.Parameters.AddWithValue("@scode", id);
                cmd.Connection.Open();
                int ra=cmd.ExecuteNonQuery();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            { cmd.Connection.Close(); }
        }

        public Entities Search_Display(int id)
        {
            try
            { 
                cmd = Data_connection.GenerateCommand();
                cmd.CommandText = "usp_search_172473";
                cmd.Parameters.AddWithValue("@scode",id);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
            
            Entities ent = new Entities();
                
                    dr.Read();
                    ent.escode = Convert.ToInt32(dr["Stud_Code"]);
                    ent.edcode = Convert.ToInt32(dr["Dept_Code"]);
                    ent.esname = Convert.ToString(dr["Stud_Name"]);
                    ent.edob = (DateTime)dr["Stud_Dob"];
                    ent.eaddress = Convert.ToString(dr["Address"]);

             return ent;
                

            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            { cmd.Connection.Close(); }
        }

        public int count()
        {
            try
            {
                cmd = Data_connection.GenerateCommand();
                cmd.CommandText = "usp_count_172473";
                cmd.Connection.Open();
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return count;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            finally
            { cmd.Connection.Close(); }

        }

        public IEnumerable<Entities> SearchWithDeptCode(int dcode)
        {
            try
            {
                cmd = Data_connection.GenerateCommand();
                cmd.CommandText = "";
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                Entities ent = new Entities();
                while (dr.Read())
                {
                    ent.escode = Convert.ToInt32(dr["Stud_Code"]);
                    ent.edcode = Convert.ToInt32(dr["Dept_Code"]);
                    ent.esname = Convert.ToString(dr["Stud_Name"]);
                    ent.edob = (DateTime)dr["Stud_Dob"];
                    ent.eaddress = Convert.ToString(dr["Address"]);
                    ent_db.Add(ent);
                }
                IEnumerable<Entities> q = from e in ent_db
                                          where e.edcode == dcode
                                          select e;
                return q;
            }

            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally { cmd.Connection.Close(); }
        }

        public DataTable ShowData()
        {
            try
            {
                cmd=Data_connection.GenerateCommand();
                cmd.CommandText = "usp_showdata_172473";
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
            
            DataTable dt = new DataTable();
            dt.Load(dr);
                
               
            //dgStudent.ItemsSource = dt.DefaultView;
             return dt;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally { cmd.Connection.Close(); }
        }

        

    }
}
