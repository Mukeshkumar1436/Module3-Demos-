﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TraineeEntity
{
   
    public class Trainee_165995
    {
        public int EmployeeId { get; set; }
        public string ModuleName { get; set; }
       
        public string BatchName { get; set; }
        public string Comments { get; set; }
    }
}
