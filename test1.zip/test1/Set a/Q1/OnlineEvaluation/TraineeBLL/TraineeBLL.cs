﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TraineeEntity;

namespace TraineeBLL
{
    public class TraineeBLL
    {
        TraineeDAL.TraineeDAL traineeDAL = new TraineeDAL.TraineeDAL();

        public bool AddStudentBLL(Trainee_165995 trainee)
        {
            bool isAdded = false;
            if (IsValid(trainee))
            {
                isAdded = traineeDAL.AddStudentDAL(trainee);
            }
            else
            {
                throw new TMSException.TMSException("Validations failed");
            }
            return isAdded;
        }


        public bool IsValid(Trainee_165995 trainee)
        {
            bool isValid = true;
            if (trainee.EmployeeId < 0 || trainee.EmployeeId > 10000)
            {
                isValid = false;
            }
     
            return isValid;
        }
        public DataTable GetAllStudentBLL()
        {
            DataTable datatable = traineeDAL.GetAllStudentDAL();
            return datatable;
        }
    }
}
