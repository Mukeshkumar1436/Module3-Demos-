﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TraineeEntity;

namespace TraineeDAL
{
    public class TraineeDAL
    {
        SqlConnection Connection = new SqlConnection(GlobalData.ConnectionString);
        public bool AddStudentDAL(Trainee_165995 trainee)
        {
            bool isAdded = false;
            try
            {
                //stored procedure
                SqlCommand Command = new SqlCommand("uspAddTrainee_165995");
                Command.CommandType = System.Data.CommandType.StoredProcedure;

                Command.Parameters.AddWithValue("@EmployeeId", trainee.EmployeeId);
                Command.Parameters.AddWithValue("@ModuleName", trainee.ModuleName);
                Command.Parameters.AddWithValue("@BatchName", trainee.BatchName);
                Command.Parameters.AddWithValue("@Comments", trainee.Comments);

                Command.Connection = Connection;
                Connection.Open();
                Command.ExecuteNonQuery();
                isAdded = true;
            }
            catch (SqlException Exception)
            {

            }
            catch (TMSException.TMSException Exception)
            {

            }
            catch (Exception Exception)
            {

            }
            finally
            {
                if (Connection.State == ConnectionState.Open)
                {
                    Connection.Close();

                }
            }
            return isAdded;
        }


        public DataTable GetAllStudentDAL()
        {

            SqlCommand command = new SqlCommand("uspGetAllTrainee_165995");
            command.CommandType = CommandType.StoredProcedure;
            command.Connection = Connection;
            DataTable table = new DataTable();
            try
            {


                Connection.Open();

                SqlDataReader reader = command.ExecuteReader();


                table.Load(reader);



            }
            catch (TMSException.TMSException ex)
            {
                throw new TMSException.TMSException(ex.Message);
            }

            finally
            {
                if (Connection.State == ConnectionState.Open)
                {
                    Connection.Close();

                }
            }
            return table;
        }
    }
}
