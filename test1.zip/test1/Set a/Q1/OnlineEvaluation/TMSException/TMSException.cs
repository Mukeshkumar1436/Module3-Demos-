﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TMSException
{
    public class TMSException : ApplicationException
    {
        public TMSException() : base() { }

        public TMSException(string message) : base(message) { }

        public TMSException(string message, Exception innerException) : base(message, innerException) { }
    }
}
