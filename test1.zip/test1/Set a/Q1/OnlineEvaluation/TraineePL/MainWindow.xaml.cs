﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TraineeEntity;

namespace TraineePL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // creating object of TraineeBLL
        TraineeBLL.TraineeBLL traineeBLL = new TraineeBLL.TraineeBLL();

        public MainWindow()
        {
            InitializeComponent();
        }

        //method to insert the data to database from user input
        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            if (AddStudentPL())
            {
                MessageBox.Show("Trainee Data Added successfully");
                GetAllStudents();
            }
            else
            {
                MessageBox.Show("Failed to Add Data");
            }

        }


        public bool AddStudentPL()
        {
            Trainee_165995 trainee = new Trainee_165995();

            trainee.EmployeeId = int.Parse(txtEmpId.Text);
            trainee.ModuleName = txtModuleName.Text;
            trainee.BatchName = txtBatchName.Text;
            trainee.Comments = txtComments.Text;
           

            bool IsAdd = traineeBLL.AddStudentBLL(trainee);
            return IsAdd;


        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //calling getallstudents method to load data on window load
            GetAllStudents();

        }

        //getallstudents method
        public void GetAllStudents()
        {
            DataTable table = traineeBLL.GetAllStudentBLL();
            dgStudent.DataContext = table;
        }
    }
}
