--creating procedure for adding trainee


CREATE PROCEDURE uspAddTrainee_165995
    @EmployeeId nvarchar(50),
    @ModuleName  nvarchar(50),
    @BatchName  nvarchar(50),
    @Comments nvarchar(150)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Trainee_165995(EmployeeId,ModuleName,BatchName,Comments)VALUES
    (@EmployeeId,@ModuleName,@BatchName,@Comments)
    
END
GO

select * from Trainee_165995



-- creatinig procedure to get details of all trainee

CREATE PROCEDURE uspGetAllTrainee_165995

AS
BEGIN
    SET NOCOUNT ON;
    select * from Trainee_165995
END















