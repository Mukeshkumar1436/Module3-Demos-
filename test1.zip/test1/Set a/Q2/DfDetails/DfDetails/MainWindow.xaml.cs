﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DfDetails
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public void GetAllStudents_165995()
        { Select * from Trainee_165995;
            
            dgStudent.DataContext = context.Student_165995.ToList();

        }
        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            Trainee_165995 student = new Trainee_165995();
            student.EmployeeId = txtEmpId.Text;
            student.ModuleName = txtModuleName.Text;
            student.BatchName = txtBatchName.Text;
            student.Comments = txtComments.Text;
           

            context.Trainee_165995.Add(student);
            context.SaveChanges();
            MessageBox.Show("data saves successfully");
            GetAllStudents_165995();
        }
    }
}
