﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DatabaseFirstApproach
{

    /// <summary>
    /// Author      : Vedanti Deshmukh
    /// Created Date: 07/01/2019
    /// Description : Presentation class to interact with the user.
    /// </summary>
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_14Nov18_MumbaiEntities Context = new Training_14Nov18_MumbaiEntities();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetAllProducts();
        }
        public void GetAllProducts()
        {

            
            var query1 = Context.ProductManagement_166082.Where(p => p.ProductCategory == "Stationary" && p.UnitsInStock > 50);
            dgProduct.DataContext = query1.OrderByDescending(p => p.ProductName).ToList();


        }

    }
}
