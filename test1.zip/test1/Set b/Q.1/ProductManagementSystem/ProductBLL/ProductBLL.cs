﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductEntity;
using ProductException;
using ProductDAL;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace ProductBLL
{

    /// <summary>
    /// Author      : Vedanti Deshmukh
    /// Created Date: 07/01/2019
    /// Description : Business logic layer to validate the data of product management system.
    /// </summary>
    public class ProductBLL
    {
        ProductDAL.ProductDAL productDAL = new ProductDAL.ProductDAL();
        public bool AddProductBLL(ProductEntity.ProductEntity product)
        {
            bool isAdded = false;

            if (ValidateProduct(product) == true)
            {
                try
                {
                    isAdded = productDAL.AddProductDAL(product);
                }
                catch (SqlException Exception)
                {
                    throw new ProductException.ProductException(Exception.Message.ToString());

                }
                catch (ProductException.ProductException Exception)
                {
                    throw new ProductException.ProductException(Exception.Message.ToString());
                }
                catch (Exception Exception)
                {
                    throw new ProductException.ProductException(Exception.Message.ToString());
                }
            }
            else
            {
                throw new ProductException.ProductException("Invalid data");
            }

            return isAdded;
        }

        public bool ValidateProduct(ProductEntity.ProductEntity product)
        {
            StringBuilder sb = new StringBuilder();
            bool ValidProduct = true;
            if (product.ProductName == string.Empty)
            {
                ValidProduct = false;
                sb.Append(Environment.NewLine + "Product Name can not be empty");
            }
            if (!Regex.IsMatch(product.ProductName, @"^[a-zA-Z]+$"))
            {
                ValidProduct = false;
                sb.Append(Environment.NewLine + "Product Name Should contain alphabets only");
            }
            if(product.Price<0 || product.UnitInStock<0)
            {
                ValidProduct = false;
                sb.Append(Environment.NewLine + "Price or Units in stock can not be less than zero");
            }

            return ValidProduct;
        }
        public List<ProductEntity.ProductEntity> GetAllProductBLL()
        {
            List<ProductEntity.ProductEntity> ProductList = new List<ProductEntity.ProductEntity>();
            try
            {
                ProductList = productDAL.GetAllProductDAL();
            }
            catch (SqlException Exception)
            {
                throw new ProductException.ProductException(Exception.Message.ToString());


            }
            catch (ProductException.ProductException Exception)
            {
                throw new ProductException.ProductException(Exception.Message.ToString());


            }
            catch (Exception Exception)
            {
                throw new ProductException.ProductException(Exception.Message.ToString());

            }
            return ProductList;
        }
    }
}