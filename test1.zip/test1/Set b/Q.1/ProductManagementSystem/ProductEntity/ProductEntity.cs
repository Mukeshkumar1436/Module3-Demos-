﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductEntity
{
    /// <summary>
    /// Author      : Vedanti Deshmukh
    /// Created Date: 07/01/2019
    /// Description : Entity class to define the basic properties and fields of product management system.
    /// </summary>
    public class ProductEntity
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string ProductCategory { get; set; }
        public int Price { get; set; }
        public int UnitInStock { get; set; }
    }
}
