﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProductEntity;
using ProductException;
using ProductBLL;
using System.Data.SqlClient;

namespace ProductPL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    /// <summary>
    /// Author      : Vedanti Deshmukh
    /// Created Date: 07/01/2019
    /// Description : Presentation layer to interact with user and take input from the same.
    /// </summary>
    public partial class MainWindow : Window
    {
        ProductBLL.ProductBLL productBLL = new ProductBLL.ProductBLL();
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetAllProductPL();
        }
        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            if (AddEmployeePL() == true)
            {
                MessageBox.Show("Product Added Successfully");
            }
            else
            {
                MessageBox.Show("Failed to Add Product");

            }
            GetAllProductPL();
        }
        private void GetAllProductPL()
        {
            try
            {
                List<ProductEntity.ProductEntity> ProductList = productBLL.GetAllProductBLL();
                dgProduct.DataContext = ProductList;

            }
            catch (SqlException Exception)
            {

                MessageBox.Show("Exception Occured" + Exception.ToString());

            }
            catch (ProductException.ProductException Exception)
            {

                MessageBox.Show("Exception Occured" + Exception.ToString());

            }
            catch (Exception Exception)
            {

                MessageBox.Show("Exception Occured" + Exception.ToString());
            }

        }
        private bool AddEmployeePL()
        {
            bool isAdded = false;

            ProductEntity.ProductEntity product = new ProductEntity.ProductEntity();
            product.ProductName = txtProductName.Text;
            product.Price = Convert.ToInt32(txtPrice.Text);
            product.UnitInStock = Convert.ToInt32(txtUnitInStock.Text);
            product.ProductCategory = ((ComboBoxItem)cbCategory.SelectedItem).Content.ToString();
            
            try
            {
                isAdded = productBLL.AddProductBLL(product);
            }
            catch (SqlException Exception)
            {
                MessageBox.Show(Exception.Message.ToString());

            }
            catch (ProductException.ProductException Exception)
            {
                MessageBox.Show(Exception.Message.ToString());
            }
            catch (Exception Exception)
            {
                MessageBox.Show(Exception.Message.ToString());
            }
            return isAdded;
        }
    }
}