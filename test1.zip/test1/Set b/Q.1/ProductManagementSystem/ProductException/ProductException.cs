﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductException
{

    /// <summary>
    /// Author      : Vedanti Deshmukh
    /// Created Date: 07/01/2019
    /// Description : Exception class to handle the different types of exceptions occured during run time.
    /// </summary>
    public class ProductException : ApplicationException
    {
        public ProductException() : base() { }

        public ProductException(string message) : base(message) { }

        public ProductException(string message, Exception innerException) : base(message, innerException) { }
    }
}
