﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductEntity;
using ProductException;

namespace ProductDAL
{

    /// <summary>
    /// Author      : Vedanti Deshmukh
    /// Created Date: 07/01/2019
    /// Description : Data access class to directly interact with the dataset as per requirement.
    /// </summary>
    public class ProductDAL
    {
        SqlConnection Connection = new SqlConnection(GlobalData.ConnectionString);
        public bool AddProductDAL(ProductEntity.ProductEntity Product)
        {
            bool isAdded = false;
            try
            {

                SqlCommand Command = new SqlCommand("AddProduct_166082");
                Command.CommandType = System.Data.CommandType.StoredProcedure;

                Command.Parameters.AddWithValue("@ProductName", Product.ProductName);
                Command.Parameters.AddWithValue("@ProductCategory", Product.ProductCategory);
                Command.Parameters.AddWithValue("@Price", Product.Price);
                Command.Parameters.AddWithValue("@UnitsInStock", Product.UnitInStock);
                Connection.Open();
                Command.Connection = Connection;
                Command.ExecuteNonQuery();
                isAdded = true;

            }
            catch (SqlException Exception)
            {
                throw new ProductException.ProductException(Exception.Message.ToString());

            }
            catch (ProductException.ProductException Exception)
            {
                throw new ProductException.ProductException(Exception.Message.ToString());
            }
            catch (Exception Exception)
            {
                throw new ProductException.ProductException(Exception.Message.ToString());
            }
            finally
            {
                Connection.Close();
            }
            return isAdded;
        }
        public List<ProductEntity.ProductEntity> GetAllProductDAL()
        {
            string Query = "GetProductDetails_166082";
            SqlCommand command = new SqlCommand(Query, Connection);
            command.CommandType = CommandType.StoredProcedure;
            List<ProductEntity.ProductEntity> ProductList = new List<ProductEntity.ProductEntity>();
            try
            {
                Connection.Open();

                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable Table = new DataTable();
                da.Fill(Table);

                foreach (DataRow row in Table.Rows)
                {
                    ProductEntity.ProductEntity Product = new ProductEntity.ProductEntity();
                    Product.ProductID = Convert.ToInt32(row["ProductId"]);
                    Product.ProductName = Convert.ToString(row["ProductName"]);
                    Product.ProductCategory = Convert.ToString(row["ProductCategory"]);
                    Product.Price = Convert.ToInt32(row["Price"]);
                    Product.UnitInStock = Convert.ToInt32(row["UnitsInStock"]);

                    ProductList.Add(Product);
                }


            }
            catch (SqlException Exception)
            {
                throw new ProductException.ProductException(Exception.Message.ToString());


            }
            catch (ProductException.ProductException Exception)
            {
                throw new ProductException.ProductException(Exception.Message.ToString());


            }
            catch (Exception Exception)
            {
                throw new ProductException.ProductException(Exception.Message.ToString());

            }
            finally
            {
                Connection.Close();
            }
            return ProductList;
        }
    }
}