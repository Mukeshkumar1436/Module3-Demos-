USE [Training_14Nov18_Mumbai]
GO
--Table creation
/****** Object:  Table [dbo].[Employee_layer]    Script Date: 05-01-2019 15:56:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ProductManagement_166082](
    [ProductId] [int] IDENTITY(1,1) NOT NULL,
    [ProductName] [varchar](MAX) NULL,
    [ProductCategory] [varchar] (20) NULL,
    [Price] [int] not NULL,
    [UnitsInStock] [int] not null 
 CONSTRAINT [PKProductManagement_166082] PRIMARY KEY CLUSTERED 
(
    [ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO



select * from ProductManagement_166082



/* Store Procedure */

/*Store procedure for add Product*/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE AddProduct_166082
    @ProductName varchar(50),
    @ProductCategory varchar(20),
    @Price int,
    @UnitsInStock int

AS
BEGIN
    
    SET NOCOUNT ON;

  
    Insert into ProductManagement_166082(ProductName,ProductCategory,Price,UnitsInStock) values(@ProductName,@ProductCategory,@Price,@UnitsInStock)
END
GO

/* Store Procedure for display  the recrods*/


/*Select select Procedure*/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      <Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Description,,>
-- =============================================
CREATE PROCEDURE GetProductDetails_166082
    -- Add the parameters for the stored procedure here
    

AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    -- Insert statements for procedure here
    Select * from ProductManagement_166082
END
GO
GetProductDetails_166082

