﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeDataBase
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static Employees_172435 employee = new Employees_172435();
        TrainingEntities context = new TrainingEntities();

        public MainWindow()
        {
            InitializeComponent();
        }

        public void ShowData()
        {
            try
            {
                context.SaveChanges();
                var data = from p in context.Employees_172435 select p;
                dgEmployee.ItemsSource = data.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                ShowData();

                /* int Id = 172435; *///Convert.ToInt32(txtSalary.Text);

                //display details of an employee based on Salary Provided
                //var employee = (from p in context.Employees_172435
                //                where p.Emp_Code == 172434
                //                select p); dgEmployee.ItemsSource = employee.ToList();

                //Insert a record in Window Loaded
                //Employees_172435 employee = new Employees_172435();
                //context.Employees_172435.Add(new Employees_172435() { Emp_Code = 101, Emp_Name = "LAYS", Emp_Salary = 45000, Emp_DOJ = DateTime.Now });

                //context.SaveChanges();

                //Display All Employee List From Database
                //dgEmployee.ItemsSource = context.Employees_172435.ToList();



                //var querry = from ins in context.Employees_172435
                //             where ins.Emp_Salary > 50000
                //             select ins;

                //context.Employees_172435.Where(ins => ins.Emp_Salary > 50000);


                //Update the record in grid
                employee = (from p in context.Employees_172435
                            where p.Emp_Code == 172434
                            select p).FirstOrDefault();
                //employee.Emp_Salary = 10000;
                //var x = (from p in context.Employees_172435
                //         where p.Emp_Code == 172434
                //         select p);
                //dgEmployee.ItemsSource = x.ToList();
                var employee1 = (from p in context.Employees_172435
                                 where p.Emp_Code == 172434
                                 select new { p.Emp_Code, p.Emp_Name });


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //private void BtnAdd_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        employee.Emp_Code = int.Parse(txtCode.Text);
        //        employee.Emp_Name = txtName.Text;
        //        employee.Emp_Salary = Convert.ToInt64(txtSalary.Text);
        //        employee.Emp_DOJ = Convert.ToDateTime(txtDOJ.Text);

        //        context.Employees_172435.Add(employee);
        //        MessageBox.Show("added");
        //        ShowData();
        //        Clear();
        //    }
        //    catch(Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}


        //Function to Perform Search Operation

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int Id = Convert.ToInt32(txtCode.Text);
                employee = (from p in context.Employees_172435
                            where p.Emp_Code == Id
                            select p).FirstOrDefault();
                txtCode.Text = Convert.ToString(employee.Emp_Code);
                txtName.Text = employee.Emp_Name;
                txtSalary.Text = Convert.ToString(employee.Emp_Salary);
                txtDOJ.Text = Convert.ToString(employee.Emp_DOJ);

                //btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        int Id = Convert.ToInt32(txtCode.Text);
        //        employee = (from p in context.Employees_172435
        //                    where p.Emp_Code == Id
        //                    select p).FirstOrDefault();
        //        employee.Emp_Code = int.Parse(txtCode.Text);
        //        employee.Emp_Name = txtName.Text;
        //        employee.Emp_Salary = Convert.ToInt64(txtSalary.Text);
        //        employee.Emp_DOJ = Convert.ToDateTime(txtDOJ.Text);

        //        ShowData();
        //        Clear();

        //        Console.WriteLine("Record Updated");

        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}


        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int Id = Convert.ToInt32(txtCode.Text);
                employee = (from p in context.Employees_172435
                            where p.Emp_Code == Id
                            select p).FirstOrDefault();
                context.Employees_172435.Remove(employee);

                ShowData();
                Clear();
                Console.WriteLine("Record Deleted");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        //private void BtnCount_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        var count = (from j in context.Employees_172435
        //                     select j).Count();
        //        MessageBox.Show("count is: " + count);

        //    }
        //    catch(Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}

        //private void Button_Click_search_DeptCode(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        int id = Convert.ToInt32(txtSalary.Text);
        //        var k = from j in context.Employees_172435
        //                where j.Emp_Salary == id
        //                select j;
        //        dgEmployee.ItemsSource = k.ToList(); Clear();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}

        public void Clear()
        {
            txtCode.Text = null;
            txtName.Text = null;
            txtSalary.Text = null;
            txtDOJ.Text = null;

            //btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
    }
}
