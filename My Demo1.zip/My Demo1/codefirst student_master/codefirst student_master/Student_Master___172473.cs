﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace codefirst_student_master
{
    class Student_Master___172473
    {
        [Key]
        public int Stud_Code { get; set; }
        public string Stud_Name { get; set; }
        public int Dept_Code { get; set; }
       
        public DateTime Doj { get; set; }
        public string address { get; set; }

    }
}
