﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace codefirst_student_master
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static Student_Master___172473 entity = new Student_Master___172473();
         db_Student_Master context = new db_Student_Master();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            //context.dbset.Add(new Student_Master___172473 {  Stud_Name = "sai kumar", Dept_Code = 10,  Doj = DateTime.Now ,address="sikkolu"});
            //context.SaveChanges();
            // // dgStudent1.ItemsSource = context.dbset.ToList();

            //var data = from p in context.dbset select p;

            //dgStudent1.ItemsSource = data.ToList();
            showdata();
           
        }

        private void Button_Click_Add(object sender, RoutedEventArgs e)
        {
            
            using (context)
            {
                entity.Stud_Code = int.Parse(tscode.Text);
                entity.Stud_Name = tsname.Text;
                entity.Dept_Code = int.Parse(tdcode.Text);
                entity.Doj = Convert.ToDateTime(tdoj.Text);
                entity.address = taddress.Text;
                
                context.dbset.Add(entity);
                
                showdata();
            }

        }

        private void Button_Click_Update(object sender, RoutedEventArgs e)
        {
            using (context)
            {
                int id = Convert.ToInt32(tscode.Text);
                entity = (from p in context.dbset
                         where p.Stud_Code==id
                         select p).FirstOrDefault();

                entity.Stud_Name = tsname.Text;
                entity.Dept_Code = int.Parse(tdcode.Text);
                entity.Doj = Convert.ToDateTime(tdoj.Text);
                entity.address = taddress.Text;

                showdata();
               
            }
        }

        private void Button_Click_Search(object sender, RoutedEventArgs e)
        {
            using (context)
            {
                int id = Convert.ToInt32(tscode.Text);
                entity = (from p in context.dbset
                          where p.Stud_Code == id
                          select p).FirstOrDefault();
                tscode.Text = Convert.ToString(entity.Stud_Code);
                tsname.Text = entity.Stud_Name;
                tdcode.Text = Convert.ToString(entity.Dept_Code);
                tdoj.Text = Convert.ToString(entity.Doj);
                taddress.Text = entity.address;
                update.IsEnabled = true; delete.IsEnabled = true;
            }
        }

       

        private void Button_Click_Delete(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(tscode.Text);
            entity = (from p in context.dbset
                      where p.Stud_Code == id
                      select p).FirstOrDefault();
            context.dbset.Remove(entity);
            showdata();Clear();
        }

        private void Button_Click_Count(object sender, RoutedEventArgs e)
        {
            var count = (from j in context.dbset select j).Count();
            MessageBox.Show("count is: "+count);

        }

        private void Button_Click_Clear(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void Button_Click_search_DeptCode(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(tscode.Text);
            var k = from j in context.dbset
                    where j.Dept_Code ==id
                    select j;
            dgStudent1.ItemsSource = k.ToList(); Clear();
        }
        public void showdata()
        {
            context.SaveChanges();
            var data = from p in context.dbset select p;
            dgStudent1.ItemsSource = data.ToList();
        }
        public void Clear()
        {
            tscode.Text = null;
            tsname.Text = null;
            tdcode.Text = null;
            tdoj.Text = null;
            taddress.Text = null;
            update.IsEnabled = false;
            delete.IsEnabled = false;
        }
    }
}
